---
name: Bug Report - Svelte
about: Submit a Svelte related issue.
title: ''
labels: svelte
assignees: pedroborges

---

### Version:

- `@inertiajs/svelte` version: #.#.#

### Describe the problem:

<!--
  Explain the behavior you're seeing that you think is a bug,
  and explain how you think things should behave instead.
-->

### Steps to reproduce:

<!--
  Please carefully explain the steps to reproduce this issue.
  We can't help you without a reproduction.
-->
