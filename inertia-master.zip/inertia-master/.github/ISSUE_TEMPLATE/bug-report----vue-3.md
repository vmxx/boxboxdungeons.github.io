---
name: Bug Report - Vue 3
about: Submit a Vue 3 related issue.
title: ''
labels: vue.js v3
assignees: ''

---

### Version:

- `@inertiajs/vue3` version: #.#.#

### Describe the problem:

<!--
  Explain the behavior you're seeing that you think is a bug,
  and explain how you think things should behave instead.
-->

### Steps to reproduce:

<!--
  Please carefully explain the steps to reproduce this issue.
  We can't help you without a reproduction.
-->
