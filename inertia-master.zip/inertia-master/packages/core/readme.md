# Inertia.js

Inertia.js lets you quickly build modern single-page React, Vue and Svelte apps using classic server-side routing and controllers.

Visit [inertiajs.com](https://inertiajs.com/) to learn more.
