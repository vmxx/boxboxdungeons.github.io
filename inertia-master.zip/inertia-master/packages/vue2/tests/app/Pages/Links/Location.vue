<template>
  <div>
    <span class="text">This is the links page that demonstrates location visits inertia-links</span>

    <inertia-link href="/location" replace class="example">Location visit</inertia-link>
  </div>
</template>
