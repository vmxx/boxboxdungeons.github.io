<template>
  <div>
    <span class="text">Simple Persistent Layout - Page B</span>
    <inertia-link href="/persistent-layouts/shorthand/simple/page-a">Page A</inertia-link>
  </div>
</template>
<script>
import Layout from '@/Layouts/SiteLayout.vue'

export default {
  layout: Layout,
}
</script>
