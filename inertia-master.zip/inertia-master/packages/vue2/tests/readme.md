# Running tests

Install dependencies:

```sh
npm install
```

To run it on the command line

```sh
npm run tes
```

To run it in the GUI:

```sh
npm run test:gui
```
