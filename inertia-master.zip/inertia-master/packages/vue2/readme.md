# Inertia.js Vue Adapter

Visit [inertiajs.com](https://inertiajs.com/) to learn more.
