export { default as default } from '@inertiajs/core/server'
