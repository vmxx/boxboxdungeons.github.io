/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./resources/**/*.blade.php', './resources/**/*.svelte'],
  theme: {
    extend: {},
  },
  plugins: [],
}
